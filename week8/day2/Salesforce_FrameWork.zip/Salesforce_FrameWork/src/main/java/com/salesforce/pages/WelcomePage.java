package com.salesforce.pages;

import com.framework.testng.api.base.ProjectSpecificMethods;

public class WelcomePage extends ProjectSpecificMethods {

}
