package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class Login extends BaseClass {
	
	
	@When("Enter the username as {string}")
	public Login enterUname(String uName) {
		getDriver().findElement(By.id("username")).sendKeys(uName);
		//Login lp=new Login();
		return this;
	}
	@When("Enter the password as {string}")
	public Login enterPassWord(String pwd) {
		getDriver().findElement(By.id("password")).sendKeys(pwd);
		return this;
	}
	@And("click on Login") 
	public WelcomePage clickLogin() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage();
	}

}
