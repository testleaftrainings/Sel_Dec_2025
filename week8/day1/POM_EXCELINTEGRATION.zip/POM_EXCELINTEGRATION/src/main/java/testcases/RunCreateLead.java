package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.Login;

public class RunCreateLead extends BaseClass{
	@BeforeTest
	public void setValues() {
		excelFileName="CreateLead";
	}
	@Test(dataProvider="fetchData")
	public void runCreateLead(String uName,String pwd,String cName,String fName,String lName) {
		//System.out.println(driver);
		Login lp=new Login(driver);
		lp.enterUname(uName).enterPassWord(pwd).clickLogin().clickCrmsfa().clickLeads().clickCreateLead().enterCname(cName)
		.enterFname(fName).enterLname(lName).clickCreateLead().verifyLeads();
		
		
	}

}
