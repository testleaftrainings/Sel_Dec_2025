package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.And;

public class CreateLeadPage extends BaseClass {
	
	@And("Enter the company Name (.*)$")
	public CreateLeadPage enterCname(String cName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
		return this;
	}
	
	@And("enter the firstName (.*)$")
	public CreateLeadPage enterFname(String fName) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
		return this;
	}
	@And("enter the LastName (.*)$")
	public CreateLeadPage enterLname(String lName) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
		return this;
	}
	@And("click on Submit button")
	public ViewLeadsPage clickCreateLead() {
		driver.findElement(By.name("submitButton")).click();
		return new ViewLeadsPage();
	}

}
